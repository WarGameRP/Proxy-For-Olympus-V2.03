const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');

const app = express();

app.use('/', createProxyMiddleware({ target: 'http://localhost:3001', changeOrigin: true }));
app.use('/api', createProxyMiddleware({ target: 'http://localhost:4513', changeOrigin: true }));
app.use('/audio', createProxyMiddleware({
    target: 'http://localhost:4000',
    changeOrigin: true,
    ws: true,
    pathRewrite: { '^/audio': '' }
}));

const server = app.listen(8080, () => {
    console.log('Proxy lancé sur http://localhost:8080');
});

server.on('upgrade', (req, socket, head) => {
    // Pour gérer les WebSockets
    if (req.url.startsWith('/audio')) {
        const proxy = createProxyMiddleware({
            target: 'http://localhost:4000',
            ws: true
        });
        proxy.upgrade(req, socket, head);
    }
});
